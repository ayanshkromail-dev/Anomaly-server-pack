Anomaly SMP Pack
================
Contains the icons for the 9 custom swords (assets/anomaly/textures/item/sword/*.png) and their item
definitions (assets/anomaly/items/sword/*.json). The plugin sets each sword's item model to
anomaly:sword/<id>, so no other setup is needed.

To combine with the fish icons: both packs use the "anomaly" namespace, so just copy the contents of the
fish pack's assets/ folder into this pack's assets/ folder (the folders do not overlap:
items/fish, textures/item/fish ...) and zip the result.
